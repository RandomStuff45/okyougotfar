"""The module for the next part of the treasure hunt."""
# pylint: disable=line-too-long
# pylint: disable=invalid-name
charnum = 177
charorigin = "README.txt"

while True:
    response = input("charnum = ? charorigin = ? For answer seperate with commas, for example '1, fh'\n")
    if response == "HINT":
        print("charnum = character number and charorigin = origin of characters. For example, '35, next_part.py'\n")
    elif response == f"{charnum}, {charorigin}":
        print("Correct! Code is 3267.\n")
    else:
        print("Incorrect\n")
